import numpy as np
import matplotlib.pyplot as plt

# Función para resolver las ecuaciones diferenciales del modelo SIR
def solve_sir_model(alpha, beta, S0, I0, R0, num_points=1000, dt=0.1):
    # Definir las ecuaciones diferenciales del modelo SIR
    def derivs(SIR):
        S, I, R = SIR
        dSdt = -alpha * S * I
        dIdt = alpha * S * I - beta * I
        dRdt = beta * I
        return [dSdt, dIdt, dRdt]

    # Método de Euler para resolver las ecuaciones diferenciales
    def euler_step(SIR):
        S, I, R = SIR
        dSdt, dIdt, dRdt = derivs(SIR)
        S_new = S + dSdt * dt
        I_new = I + dIdt * dt
        R_new = R + dRdt * dt
        return [S_new, I_new, R_new]

    # Inicializar listas para almacenar resultados
    S_list = [S0]
    I_list = [I0]
    R_list = [R0]

    # Ejecutar el método de Euler para resolver las ecuaciones diferenciales
    for _ in range(num_points):
        S_new, I_new, R_new = euler_step([S_list[-1], I_list[-1], R_list[-1]])
        S_list.append(S_new)
        I_list.append(I_new)
        R_list.append(R_new)

    # Convertir listas a arrays numpy para facilitar la manipulación
    S_array = np.array(S_list)
    I_array = np.array(I_list)
    R_array = np.array(R_list)

    return S_array, I_array, R_array

# Parámetros iniciales
S0 = 0.99
I0 = 0.01
R0 = 0.0

# Nuevos valores de alpha y beta
alpha_initial = 0.2
beta_initial = 0.1

# Resolver el modelo SIR con los nuevos valores
S, I, R = solve_sir_model(alpha_initial, beta_initial, S0, I0, R0)

# Graficar los resultados
plt.plot(S, label='Susceptibles')
plt.plot(I, label='Infectados')
plt.plot(R, label='Recuperados')

# Graficar los valores iniciales como líneas horizontales
plt.axhline(y=S0, color='b', linestyle='--', label='Valor inicial de S')
plt.axhline(y=I0, color='g', linestyle='--', label='Valor inicial de I')
plt.axhline(y=R0, color='r', linestyle='--', label='Valor inicial de R')

plt.xlabel('Tiempo')
plt.ylabel('Proporción de la población')
plt.title('Modelo SIR')
plt.legend()
plt.show()
